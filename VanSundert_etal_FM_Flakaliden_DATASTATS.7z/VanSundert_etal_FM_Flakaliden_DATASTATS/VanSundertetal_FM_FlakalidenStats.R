Tb=read.table('FlakalidenData2016.txt',header=T)
attach(Tb)
Treatment = as.factor(Treatment)

############################################################

### TABLE 1 ###

Stand characteristics 
  & productivity related variables

Method: ANOVA 
    (or kruskal test as non-parametric alternative)

############################################################

# Example: volume increment 1986-2016
VI_8616 = V_2016-V_1986

hist(VI_8616)
shapiro.test(VI_8616)

lm1 = lm(VI_8616 ~ Treatment)

shapiro.test(lm1$residuals)
bartlett.test(VI_8616~Treatment)

anova(lm1)
TukeyHSD(aov(VI_8616 ~ Treatment))

kruskal.test(<response.var> ~ Treatment)
pairwise.wilcox.test(<response.var>,TT,p.adj='bonferroni')

## Analogous for other (changes in) stand characteristics

############################################################

### FIGS 1, 2 & 4 ###

Correlation structure

  Method: PCA
  
############################################################

  
## FIG 1 - PCA on needle nutrients & stoichiometry

  logneedle_Mg=log(needle_Mg)
  y=cbind(needle_N,needle_P,needle_K,needle_Ca,logneedle_Mg,needle_CN)
  pairs(y)
  pc1=princomp(y,cor=T)
  loadings(pc1)
  summary(pc1)
  screeplot(pc1)
  par(mfrow=c(1,1))
  biplot(pc1,pc.biplot=T,xlabs=Treatment)
  cor(y)
  cor.test(needle_N,needle_P)
  
## ggplot version
  
  Tb$TT <- factor(Tb$Treatment, levels = c("C", "10y-IL","30y-IL"))
  Tb$Treatment=as.factor(Tb$TT)
  library(ggfortify)
  autoplot(pc1, data = Tb, shape = 'Treatment', colour = 'Treatment',
           loadings = TRUE, loadings.colour = 'black',
           loadings.label = F, loadings.label.size = 7,
           loadings.label.vjust = 0.1,size=7, frame = F, frame.type = "norm") +
    theme_bw() +
    xlab("PC1 (46.8 % of variance)") +
    ylab("PC2 (30.8 % of variance)") +
    labs(col="Treatment") + 
      theme(axis.text=element_text(size=16),axis.title=element_text(size=18,face="bold"),legend.text=element_text(size=14),legend.title=element_text(size=14,face="bold"))+  
    annotate("text", x=0.475, y=0.25, label= "N",size=7)+
    annotate("text", x=0.055, y=0.525, label= "P",size=7)+
    annotate("text", x=-0.24, y=0.55, label= "K",size=7)+
    annotate("text", x=-0.48, y=0.07, label= "Ca",size=7)+
    annotate("text", x=-0.30, y=0.35, label= "ln(Mg)",size=7)+
    annotate("text", x=-0.48, y=-0.25, label= "C:N",size=7)

## FIG 2 - PCA on soil properties and nutrients

  log_SOC1=log(SOC1)
  log_TN1=log(N1)
  log_BD1=log(BD1)
  y=cbind(log_SOC1,log_TN1,log_BD1,CN1,pHw1,pHKCl1,CEC1,TEB1,BS1,PBray1)
  pairs(y)
  pc2=princomp(y,cor=T)
  loadings(pc2)
  summary(pc2)
  screeplot(pc2)
  par(mfrow=c(1,1))
  biplot(pc2,pc.biplot=T,xlabs=Treatment)
  cor(y)
  cor.test(log(SOC1),log(BD1))
  
  ## ggplot version
  
  Tb$TT <- factor(Tb$Treatment, levels = c("C", "10y-IL","30y-IL"))
  Tb$Treatment=as.factor(Tb$TT)
  library(ggfortify)
  autoplot(pc2, data = Tb, shape = 'Treatment', colour = 'Treatment',
           loadings = TRUE, loadings.colour = 'black',
           loadings.label = F, loadings.label.size = 7,
           loadings.label.vjust = 0.1,size=5, frame = F, frame.type = "norm") +
    theme_bw() +
    xlab("PC1 (58.3 % of variance)") +
    ylab("PC2 (22.0 % of variance)") +
    labs(col="Treatment") + 
    theme(axis.text=element_text(size=16),axis.title=element_text(size=18,face="bold"),legend.text=element_text(size=14),legend.title=element_text(size=14,face="bold"))+
    annotate("text", x=0.395, y=0.05, label= "ln(SOC)",size=7)+
    annotate("text", x=0.385, y=0.21, label= "ln(TN)",size=7)+
    annotate("text", x=0.13, y=-0.21, label= "C:N",size=7)+
    annotate("text", x=-0.26, y=0.38, label= "pH_w",size=7)+
    annotate("text", x=-0.33, y=0.32, label= "pH_KCl",size=7)+
    annotate("text", x=0.38, y=0.10, label= "CEC",size=7)+
    annotate("text", x=0.275, y=0.385, label= "TEB",size=7)+
    annotate("text", x=-0.115, y=0.52, label= "BS",size=7)+
    annotate("text", x=0.39, y=0.16, label= "P_Bray",size=7)+
    annotate("text", x=-0.30, y=0.20, label= "ln(BD)",size=7)
  
## FIG 4 - PCA on PRS supply rates
  
  logPRS_iN=log(PRS_iN)
  logPRS_NH4=log(PRS_NH4)
  logPRS_NO3=log(PRS_NO3)
  logPRS_K=log(PRS_K)
  logPRS_Mg=log(PRS_Mg)
  ratio=PRS_NO3/PRS_iN
  y=cbind(logPRS_iN,logPRS_NH4,logPRS_NO3,logPRS_K,logPRS_Mg,ratio,PRS_P,PRS_Ca)
  pairs(y)
  pc3=princomp(y,cor=T)
  loadings(pc3)
  summary(pc3)
  screeplot(pc3)
  par(mfrow=c(1,1))
  biplot(pc3,pc.biplot=T,xlabs=Treatment)
  cor(y)
  cor.test(log(PRS_NH4),log(PRS_NO3))
  
  ## ggplot version
  
  Tb$TT <- factor(Tb$TT, levels = c("C", "10y-IL","30y-IL"))
  Tb$Treatment=as.factor(Tb$Treatment)
  library(ggfortify)
  autoplot(pc3, data = Tb, shape = 'Treatment', colour = 'Treatment',
           loadings = TRUE, loadings.colour = 'black',
           loadings.label = F, loadings.label.size = 7,
           loadings.label.vjust = 0.1,size=5) +
    theme_bw() +
    xlab("PC1 (68.7 % of variance)") +
    ylab("PC2 (14.4 % of variance)") +
    labs(col="Treatment") + 
    theme(axis.text=element_text(size=16),axis.title=element_text(size=18,face="bold"),legend.text=element_text(size=14),legend.title=element_text(size=14,face="bold"))+
    annotate("text", x=0.30, y=0.115, label= "ln(iN)",size=7)+
    annotate("text", x=0.31, y=-0.125, label= "ln(NH4+)",size=7)+
    annotate("text", x=0.25, y=0.205, label= "ln(NO3-)",size=7)+
    annotate("text", x=0.20, y=0.285, label= "NO3- : iN",size=7)+
    annotate("text", x=0.27, y=0.05, label= "iP",size=7)+
    annotate("text", x=0.33, y=-0.06, label= "ln(K)",size=7)+
    annotate("text", x=0.09, y=-0.47, label= "Ca",size=7)+
    annotate("text", x=0.23, y=-0.28, label= "ln(Mg)",size=7)

  
############################################################

### TABLES 2, 3 & 4 ###
  
Needle stoichiometry, soil Characteristics 
  & PRS supply rates per Treatment
	
	Method: ANOVA
    	(or kruskal test as non-parametric alternative)
	
############################################################

	hist(needle_N)
	shapiro.test(needle_N)
	
	lm1 = lm(needle_N ~ Treatment)
	
	shapiro.test(lm1$residuals)
	bartlett.test(needle_N ~ Treatment)
	
	anova(lm1)
	TukeyHSD(aov(needle_N ~ Treatment))
	
	kruskal.test(<response.var> ~ Treatment)
	pairwise.wilcox.test(<response.var>,TT,p.adj='bonferroni')
	
	## Analogous for other needle & soil characteristics, & PRS nutrient supply rates

############################################################

### FIG	5 & TABLES S4-6 ###
	
Structural Equation Model - soil C:N endpoint

############################################################

library(lavaan)

Tb10yIL=Tb[Treatment!="2",]
Tb30yIL=Tb[Treatment!="1",]

model <- ' 

### regressions
VI_8616 ~ a1*Treatment
SOC1 ~ a2*VI_8616
needle_CN ~ b1*Treatment
CN1~a3*SOC1+b2*needle_CN+c*Treatment

Indirect_SOC := a1*a2*a3
Indirect_needle := b1*b2
Direct := c
Indirect := Indirect_SOC + Indirect_needle 

## 
## # residual covariances
'

fit <- sem(model, data=Tb10yIL,estimator="MLM")
summary(fit,standardized=T,fit.measures=T)

############################################################

### FIG S1 & TABLES S4-6 ###

Structural Equation Model 
- indirect effects on CEC and Bulk Density

############################################################

library(lavaan)

Tb10yIL=Tb[Treatment!="2",]
Tb30yIL=Tb[Treatment!="1",]

model <- ' 


### regressions
VI_8616 ~ a1*Treatment
SOC1 ~ a2*VI_8616
CEC1 ~ a3*SOC1
BD1 ~ a4*SOC1

## 
## # residual covariances

'

fit <- sem(model, data=Tb,estimator="MLM")
summary(fit,standardized=T,fit.measures=T)

############################################################

### FIGURE S2 & TABLES S4-6 ###

Structural Equation Model - Total Nitrogen endpoint

############################################################

y10yIL=Tb[Treatment!="2",]
y30yIL=Tb[Treatment!="1",]

model <- ' 


### regressions
VI_8616 ~ a1*Treatment
SOC1 ~ a2*VI_8616
CEC1 ~ a3*SOC1
BD1 ~ a5*SOC1
needle_N ~ b1*Treatment
N1 ~ a4*BD1 + b2*needle_N + c1*Treatment + a6*CEC1

## 
## # residual covariances

Indirect_SOC := a1*a2*(a3*a4+a5*a6)
Indirect_needle := b1*b2
Direct := c1
Indirect := Indirect_SOC + Indirect_needle
'

fit <- sem(model, data=Tb10yIL,estimator="MLM")
summary(fit,standardized=T,fit.measures=T)

############################################################

### FIG	S3 & TABLES S4-6 ###

Structural Equation Model - "plant-available" P endpoint

############################################################

model <- ' 

### regressions

VI_8616 ~ a1*Treatment
SOC1 ~ a2*VI_8616
BD1 ~ a3*SOC1
needle_P ~ b1*Treatment
PBray1 ~ a4B*BD1 + b2B*needle_P + c1B*Treatment

## 
## # residual covariances

Indirect_SOC_Bray := a1*a2*a3*a4B
Indirect_needle_Bray := b1*b2B
Direct_Bray := c1B
Indirect_Bray := Indirect_SOC_Bray + Indirect_needle_Bray
'

fit <- sem(model, data=Tb,estimator="MLM")
summary(fit,standardized=T,fit.measures=T)

############################################################

### FIG	S4 & TABLES S4-6 ###

Structural Equation Model - exchangeable base cations endpoint

############################################################

needle_bases = needle_Ca + needle_K + needle_Mg
y = cbind(Tb,needle_bases)
y10yIL=y[Treatment!="2",]
y30yIL=y[Treatment!="1",]

model <- ' 


### regressions
VI_8616 ~ a1*Treatment
SOC1 ~ a2*VI_8616
CEC1 ~ a3*SOC1
BD1 ~ a5*SOC1
needle_bases ~ b1*Treatment
TEB1 ~ a6*BD1 + b2*needle_bases + c1*Treatment + a4*CEC1

## 
## # residual covariances

Indirect_SOC := a1*a2*(a3*a4+a5*a6)
Indirect_needle := b1*b2
Direct := c1
Indirect := Indirect_SOC + Indirect_needle
'

fit <- sem(model, data=y10yIL,estimator="MLM")
summary(fit,standardized=T,fit.measures=T)

############################################################

### TABLE S6 ###

Correlations & ANOVAs for path diagrams

############################################################

cor.test(VI_8616[Treatment!="2"],SOC1[Treatment!="2"],method="spearman")

lm1 = lm(VI_8616[Treatment!="2"] ~ Treatment[Treatment!="2"])

shapiro.test(lm1$residuals)
bartlett.test(<response.var> ~ Treatment[Treatment!=<level.excluded>])

anova(lm1)
         
kruskal.test(VI_8616[Treatment!="2"] ~ Treatment[Treatment!="2"])

## Analogous for other variables in the schemes.

############################################################
############################################################

detach(Tb)
rm(list=ls())
